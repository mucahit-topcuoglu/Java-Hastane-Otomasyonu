-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: hastane
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `odeme_gecmisi`
--

DROP TABLE IF EXISTS `odeme_gecmisi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `odeme_gecmisi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fatura_id` int DEFAULT NULL,
  `odeme_miktari` decimal(10,2) DEFAULT NULL,
  `odeme_tarihi` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fatura_id` (`fatura_id`),
  CONSTRAINT `odeme_gecmisi_ibfk_1` FOREIGN KEY (`fatura_id`) REFERENCES `faturalar` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `odeme_gecmisi`
--

LOCK TABLES `odeme_gecmisi` WRITE;
/*!40000 ALTER TABLE `odeme_gecmisi` DISABLE KEYS */;
INSERT INTO `odeme_gecmisi` VALUES (1,3,30.00,'2025-01-24 01:07:35'),(2,3,30.00,'2025-01-24 01:07:47'),(3,7,30.00,'2025-01-24 01:38:31'),(4,11,4.00,'2025-01-24 02:20:17'),(5,15,22.00,'2025-01-24 02:55:27'),(6,15,278.10,'2025-01-24 02:55:50'),(7,8,150.00,'2025-01-24 03:02:48'),(8,12,123.00,'2025-01-24 00:00:00'),(11,6,4.00,'2025-01-24 00:00:00'),(12,14,50.00,'2025-01-24 17:37:09');
/*!40000 ALTER TABLE `odeme_gecmisi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-24 17:43:57
